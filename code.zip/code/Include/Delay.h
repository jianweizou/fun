void Timer0_Init(void);

void Timer1_Delay100us(unsigned long cnt);
