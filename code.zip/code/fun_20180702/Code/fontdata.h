

extern code unsigned char font_CHN[];
extern code unsigned char font1_0_9[];
extern code unsigned char font2_0_9[];
extern code unsigned char font_A_Z[];
extern code unsigned char t0[];



typedef enum
{
	SAN,
	ZHONG,
	WEN,
	SHU,
	ZI,
	ZANG,
	GUI,
	LING,
	CHONG,
	ZHI,
	SHI,
	FOU,
	CHNEND,
}CHN;

