

extern void KeyInit(void);
extern char KeyScan(void);
extern void EnterDPD(void);